//
//  main.swift
//  lettcode
//
//  Created by 吴孜健 on 2020/2/12.
//  Copyright © 2020 ausband. All rights reserved.
//

import Foundation

public class TreeNode {
    public var val: Int
    public var left: TreeNode?
    public var right: TreeNode?
    public init(_ val: Int) {
        self.val = val
        self.left = nil
        self.right = nil
    }
}

class Solution {
    func sortedArrayToBST(_ nums: [Int]) -> TreeNode? {
        let root = self.helper(0, nums.count-1, nums)
        return root
    }
    func helper(_ left : Int, _ right :Int, _ nums: [Int]) -> TreeNode? {
        if left > right {
            return nil
        }
        
        let p = (left+right)/2
        let root = TreeNode(nums[p])
        root.left = helper(left, p-1, nums)
        root.right = helper(p+1, right, nums)
        return root
    }
    
    func isBalanced(_ root: TreeNode?) -> Bool {
        
    }
}

let s = Solution()
s.sortedArrayToBST([-10,-3,0,5,9])

print("Hello, World!")

